INSERT INTO proyecto.novedades (titulo,descripcion,fecha_publicacion,estado) VALUES
	 ('https://electromecanicarodrigo.com/','Funcionante','2024-04-01',1),
	 ('https://infermiereacasatua.com/','Modificarla completa','2024-04-01',0);
